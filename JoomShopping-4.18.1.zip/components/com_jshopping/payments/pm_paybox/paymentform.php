<script type="text/javascript">
function check_pm_paybox(){
    $_('payment_form').submit();
}
</script>