<?php
// Platron
define('_JSHOP_paybox_TEST_MODE_DESCRIPTION','Для проведения оплат в тестовом режиме ');
define('_JSHOP_paybox_MERCHANT_ID','Номер магазина в PayBox ');
define('_JSHOP_paybox_MERCHANT_ID_DESCRIPTION','Свой номер магазина можно узнать на по адресу https://my.paybox.money нажав подробнее');
define('_JSHOP_paybox_SECRET_KEY','Секретное слово');
define('_JSHOP_paybox_SECRET_KEY_DESCRIPTION','Можно узнать так же по адресу https://my.paybox.money');
define('_JSHOP_paybox_LIFETIME','Время жизни счета');
define('_JSHOP_paybox_LIFETIME_DESCRIPTION','В часах. Максимальное значение 168. Используется в ПС, не поддерживающих CHECK');
define('_JSHOP_paybox_TRANSACTION_END_DESCRIPTION','Выберите статус заказа, который будет установлен, если транзакция в PayBox прошла успешно. ');
define('_JSHOP_paybox_TRANSACTION_PENDING_DESCRIPTION','Выберите статус заказа, который будет установлен, если транзакция в PayBox незавершена. ');
define('_JSHOP_paybox_TRANSACTION_FAILED_DESCRIPTION','Выберите статус заказа, который будет установлен, если транзакция в PayBox прошла неуспешно. ');
define('_JSHOP_paybox_ENABLE_OFD','Включить ОФД');
define('_JSHOP_paybox_TAX_TYPE','Тип налога');
?>

